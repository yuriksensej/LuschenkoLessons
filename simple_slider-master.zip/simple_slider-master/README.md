# ITGID.info
## Simple Slider
### https://itgid.info

Простой слайдер на javascript. Возможность листания в правую и левую сторону, перемотка.
### Посмотреть видеоурок на Youtube
https://youtu.be/UsLpqTXd5vs
[![Посмотреть видео](https://github.com/itgidinfo/simple_slider/blob/master/images/cover.png?raw=true)](https://youtu.be/UsLpqTXd5vs)

### Курсы ItGid.info

- JavaScript 2.0 (https://itgid.info/course/javascript-2)
- HTML для будущих JS разработчиков (https://itgid.info/course/html)
- Методы массивов JavaScript (https://itgid.info/course/arraymethod)
- ReactJS (https://itgid.info/course/reactjs)

В каждом курсе вас ждет много практических задач, поддержка, проверка ДЗ, разбор ошибок, помощью в решении
